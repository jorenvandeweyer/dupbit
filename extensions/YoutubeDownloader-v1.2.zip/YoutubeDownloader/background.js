queue = [];
session = "";

function download(qid, ytid, title, artist) {
	$.ajax({
		url: "https://dupbit.com/projects/music/addSong",
		type: "post",		
		data: {ytid: ytid, title: title, artist: artist},
		xhrFields : {
			withCredentials: true
		}
	}).done(function(sid){
		if (title != "" && artist != "") {
			var name = artist + " - " + title;	
		}
		else if (title == "" && artist != "") {
			var name = artist;
		}
		else if (title != "" && artist == "") {
			var name = title;
		}
		else if (title == "" && artist == "") {
			var name = ytid;
		}

		chrome.downloads.download({url: "https://dupbit.com/projects/music/downloadSong?id="+sid, filename: "youtubedownloader/"+name+".mp3"});
		queue[qid].readyState = true;
		var views = chrome.extension.getViews({
			type: "popup"
		});
		for (var i = 0; i < views.length; i++) {
			views[i].updateQueueReadyState(qid);
		}
	});
}

