function isYoutubeVideo(url) {
	return url.indexOf("https://www.youtube.com/watch?v=") >= 0;
}

function getId(url) {
		var ytid = url.split('v=')[1];
		var ampersandPosition = ytid.indexOf('&');
		if(ampersandPosition != -1) {
			ytid = ytid.substring(0, ampersandPosition);
		}
		return ytid;
}

function getVideoName(title) {
	return title.replace(" - YouTube", "");
}

var session = chrome.extension.getBackgroundPage().session;
var queue = chrome.extension.getBackgroundPage().queue;
var queueTableBody = $("#queue tbody");

function showQueue() {	
	for (qid in queue) {
		var item = queue[qid];
		addToQueue(qid, item.artist, item.title, item.readyState);
	}
	if (queue.length > 0) {
		$("#queue").show();
	}
}

function hideQueue() {
	$("#queue").hide();
}

function addToQueue(qid, artist, title, readyState) {
	imgSrc = readyState ? "ready.png": "loading.gif";
	queueTableBody.prepend("<tr id='"+qid+"'><td>"+artist+"</td><td>"+title+"</td><td><img  width='16px' src='images/"+imgSrc+"'/></td>/tr>");
	$("#queue").show();
}

function updateQueueReadyState(qid) {
	queueTableBody.find("#"+qid+" img").attr("src", "images/ready.png");
}

function showMessage(string) {
	$("#message span").text(string);	
	$("#message").show();	
} 

function hideMessage() {
	$("#message").hide();
}

function showDownload(videoName) {
	if (videoName.indexOf(" - ") > -1) {
		var artist = videoName.split(" - ")[0].replace(/[\\\/:*?"<>|]/g, "");
		var title = videoName.split(" - ")[1].replace(/[\\\/:*?"<>|]/g, "");		
	}
	else {
		var artist = "";
		var title = videoName;		
	}	
	
	$("#artist").val(artist);
	$("#title").val(title);	
	$("#download").show();	
	$("#title").select();	
}

function hideDownload() {
	$("#download").hide();	
}

function showLogin(tab) {
	$("#submit").removeClass("disabled");
	$("#login").show();
}

function hideLogin() {
	$("#login").hide();	
}

function updatePopup(tab) {
	$.ajax({
		url: "https://dupbit.com/ajax/loginStatus.php",
		type: "get",
		xhrFields : {
			withCredentials: true
		}
	}).done(function(data){
		data = JSON.parse(data);
		logged = data.logged;
		if (logged) {	
			authorized = data.details.level >= 2
			if (authorized) {
				if (isYoutubeVideo(tab.url)) {
					var videoName = getVideoName(tab.title);
					hideMessage();	
					showDownload(videoName);	
				}			
				else {
					hideDownload();
					showMessage("Go to a YouTube video to download it.");
				}			
				showQueue();
			}
			else {
				hideDownload();	
				hideQueue();
				showMessage("You have no permission to use this app.");				
			}
			hideLogin();				
		}
		else {
			hideDownload();
			hideQueue();
			hideMessage();
			showLogin(tab);			
		}
		var height = $("#banner").outerHeight() + $("#message:visible").outerHeight() + $("#download:visible").outerHeight() + $("#queue:visible").outerHeight();
		$("html, body").height(height);	
	});
}

function login(tab, username, password) {
	$.ajax({
		url: "https://dupbit.com/ajax/login.php",
		type: "post",
		data: {username: username, password: password},
		xhrFields : {
			withCredentials: true
		}
	}).done(function(data){
		updatePopup(tab);	
	});
} 

chrome.tabs.query({active: true, currentWindow: true}, function(tabList) {
	
	tab = tabList[0];
	
	$("#login form").submit(function() {
		$("#submit").addClass("disabled");
		var username = $("#username").val();
		var password = $("#password").val();
		login(tab, username, password);		
		return false;
	});		

	if (isYoutubeVideo(tab.url)) {
		var ytid = getId(tab.url);	
		
		$("#download form").submit(function() {
			var artist = $("#artist").val().replace(/[\\\/:*?"<>|]/g, "");
			var title = $("#title").val().replace(/[\\\/:*?"<>|]/g, "");
			var qid = queue.length;
			queue.push({artist: artist, title: title, readyState: false});
			addToQueue(qid, artist, title, false);
			chrome.extension.getBackgroundPage().download(qid, ytid, title, artist);
			return false;
		});	
	}	
	
	updatePopup(tab);	
});